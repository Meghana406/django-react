import { response } from "express";
import React from "react"

class Greetings extends React.Component{
    // constructor(props) {
    //     super(props);
    //     this.state = {
    //         person : {}
    //     };
    // }


    // UserList(){
    //   return $.getJSON('http://dummy.restapiexample.com/api/v1/employees')
    //     .then(function(data) {
    //       return data.results;
    //     });
    // }

    render(){
        // console.log(this.)
    //    this.UserList().then(function(res){
    //         console.log(res,"response")
    //       });

        return (
           <div className="jumbotron">
                {!this.props.auth.isAuthenticated &&
                <h1>Hi! Welcome to the DRR Demo. Have you signed up yet?</h1>}
                {this.props.auth.isAuthenticated &&
                  <div>
                      Hello
                  </div>

                }

           </div>
        )
    }
}

export default Greetings